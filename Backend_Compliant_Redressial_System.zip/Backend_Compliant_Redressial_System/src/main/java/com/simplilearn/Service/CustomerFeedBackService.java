package com.simplilearn.Service;

import com.simplilearn.Entity.CustomerFeedback;

public interface CustomerFeedBackService {
	
	public CustomerFeedback sendFeedback(CustomerFeedback customerFeedback);

}
