package com.simplilearn.Service;

import com.simplilearn.Entity.ContactUs;

public interface ContactUsService {
	
	public ContactUs contactUs(ContactUs contactUs);

}
